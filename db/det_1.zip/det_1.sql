-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               9.1.0 - MySQL Community Server - GPL
-- Server OS:                    Linux
-- HeidiSQL Version:             12.8.0.6908
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping data for table det.comments: ~0 rows (approximately)

-- Dumping data for table det.events: ~0 rows (approximately)

-- Dumping data for table det.follows: ~0 rows (approximately)

-- Dumping data for table det.image: ~16 rows (approximately)
REPLACE INTO `image` (`id`, `post_id`, `img_path`) VALUES
	(1, 1, '/img/post/post_1.jpg'),
	(2, 1, '/img/post/post_2.jpg'),
	(3, 5, '/img/post/optimized-1737309730343-544996842.jpg'),
	(4, 5, '/img/post/optimized-1737309731200-321187555.jpg'),
	(5, 7, '/img/post/optimized-1737313428355-72512683.jpg'),
	(6, 8, '/img/post/optimized-1737313448139-532046269.jpg'),
	(7, 8, '/img/post/optimized-1737313448870-697408099.jpg'),
	(8, 9, '/img/post/optimized-1737313552785-315527369.jpg'),
	(9, 20, '/img/post/optimized-1737314771438-634134680.jpg'),
	(10, 20, '/img/post/optimized-1737314772239-453792873.jpg'),
	(11, 21, '/img/post/optimized-1737315078852-560665173.jpg'),
	(12, 21, '/img/post/optimized-1737315078990-674955766.png'),
	(13, 21, '/img/post/optimized-1737315079079-873527168.png'),
	(14, 21, '/img/post/optimized-1737315079163-703390810.jpg'),
	(15, 21, '/img/post/optimized-1737315079816-173254881.jpg'),
	(33, 28, '/img/post/optimized-1737392694856-735215194.jpg'),
	(38, 30, '/img/post/optimized-1737400830532-567959847.jpg'),
	(39, 30, '/img/post/optimized-1737400831594-722238972.jpg'),
	(40, 30, '/img/post/optimized-1737400831764-204510464.jpg'),
	(41, 30, '/img/post/optimized-1737400831785-496710056.png');

-- Dumping data for table det.likes: ~0 rows (approximately)
REPLACE INTO `likes` (`like_id`, `user_id`, `post_id`, `created_at`) VALUES
	(32, 3, 28, '2025-01-20 18:36:15'),
	(33, 2, 28, '2025-01-20 18:54:24'),
	(36, 1, 28, '2025-01-20 19:21:49'),
	(37, 1, 30, '2025-01-20 19:21:57'),
	(41, 2, 30, '2025-01-20 19:54:48');

-- Dumping data for table det.messages: ~0 rows (approximately)

-- Dumping data for table det.notifications: ~2 rows (approximately)
REPLACE INTO `notifications` (`notification_id`, `user_id`, `sender_id`, `post_id`, `message`, `is_read`, `created_at`) VALUES
	(1, 2, 3, 28, 'ชอบโพสต์ของคุณ', 0, '2025-01-20 18:36:15'),
	(2, 2, 1, 17, 'ชอบโพสต์ของคุณ', 0, '2025-01-20 18:55:56'),
	(3, 2, 1, 28, 'ชอบโพสต์ของคุณ', 0, '2025-01-20 19:21:49'),
	(4, 3, 1, 30, 'ชอบโพสต์ของคุณ', 0, '2025-01-20 19:21:57'),
	(5, 3, 2, 30, 'ชอบโพสต์ของคุณ', 0, '2025-01-20 19:25:58'),
	(6, 3, 2, 30, 'ชอบโพสต์ของคุณ', 0, '2025-01-20 19:26:00'),
	(7, 3, 2, 30, 'ชอบโพสต์ของคุณ', 0, '2025-01-20 19:26:01'),
	(8, 3, 2, 30, 'ชอบโพสต์ของคุณ', 0, '2025-01-20 19:54:48');

-- Dumping data for table det.posts: ~21 rows (approximately)
REPLACE INTO `posts` (`post_id`, `user_id`, `content`, `like_count`, `created_at`) VALUES
	(1, 1, 'นี่คือโพสต์ทดสอบโดยไม่มีรูปภาพ', 0, '2025-01-19 15:57:55'),
	(2, 1, 'นี่คือโพสต์ทดสอบโดยไม่มีรูปภาพ', 0, '2025-01-19 15:59:55'),
	(3, 2, 'นี่คือโพสต์ทดสอบโดยไม่มีรูปภาพ', 0, '2025-01-19 16:14:51'),
	(4, 2, 'geargamu', 0, '2025-01-19 17:59:43'),
	(5, 2, 'geargamu', 0, '2025-01-19 18:02:11'),
	(6, 2, 'dddddd', 0, '2025-01-19 19:03:15'),
	(7, 2, 'sawatdee prated thai', 0, '2025-01-19 19:03:49'),
	(8, 2, 'sawatdee prated thai 22222222', 0, '2025-01-19 19:04:09'),
	(9, 1, 'eeeeeeee', 0, '2025-01-19 19:05:53'),
	(10, 1, 'cvxcvvxcvxcvxcv', 0, '2025-01-19 19:07:50'),
	(11, 2, 'fffff', 0, '2025-01-19 19:09:04'),
	(12, 2, 'sssss', 0, '2025-01-19 19:09:29'),
	(13, 2, 'ssssssadasdasdasd', 0, '2025-01-19 19:09:42'),
	(14, 1, 'sdfsdfsdf', 0, '2025-01-19 19:14:11'),
	(15, 2, 'dfsfsdfsdfsdfsdfsdfsdf', 0, '2025-01-19 19:18:09'),
	(16, 1, 'dfsfsdfsdfsdfsdfsdfsdf', 0, '2025-01-19 19:18:25'),
	(17, 1, 'qqqqqqqqqqqqqq', 0, '2025-01-19 19:20:34'),
	(18, 2, 'asdasdasdasdd', 0, '2025-01-19 19:20:58'),
	(19, 1, 'jhonnnnnnnnnnnn', 0, '2025-01-19 19:23:22'),
	(20, 1, 'I love travelllll.', 0, '2025-01-19 19:26:12'),
	(21, 1, 'genshin impact 3.0', 0, '2025-01-19 19:31:20'),
	(28, 2, 'ffff', 0, '2025-01-20 17:04:55'),
	(30, 3, 'im sad!!!!cxvxcdfxcbv', 0, '2025-01-20 19:20:32');

-- Dumping data for table det.posttags: ~0 rows (approximately)

-- Dumping data for table det.tags: ~0 rows (approximately)

-- Dumping data for table det.users: ~3 rows (approximately)
REPLACE INTO `users` (`user_id`, `username`, `email`, `password_hash`, `full_name`, `bio`, `created_at`, `link`, `profile_img`) VALUES
	(1, 'johndoe', 'user@example.com', '$2a$08$kKEtI5i4NwbH2B6wkBaA5OdEoDZ2d2P.bwfwjRFRvgTmMGHRPAC92', 'John Doe', 'I love genshin', '2025-01-16 13:10:22', 'No link', '/img/processed/1737400903233.jpg'),
	(2, 'geargumi', 'gumi@gmail.com', '$2a$08$kKEtI5i4NwbH2B6wkBaA5OdEoDZ2d2P.bwfwjRFRvgTmMGHRPAC92', 'เกียร์ที่แปลว่าเก ><', '名: Gear | ギヤ  เกียร์', '2025-01-16 13:19:28', 'tiktok.com/@gamucosu', '/img/processed/1737397243053.png'),
	(3, 'coscos', 'cos@gamil.com', '$2a$08$kKEtI5i4NwbH2B6wkBaA5OdEoDZ2d2P.bwfwjRFRvgTmMGHRPAC92', 'CosC_COs', 'fegfshrsjsrjn', '2025-01-19 19:35:00', 'tiktok.com/@coscos', '/img/processed/1737400824215.jpg');

-- Dumping data for table det._prisma_migrations: ~1 rows (approximately)
REPLACE INTO `_prisma_migrations` (`id`, `checksum`, `finished_at`, `migration_name`, `logs`, `rolled_back_at`, `started_at`, `applied_steps_count`) VALUES
	('9ba60f65-33c1-4bef-a58f-b8d19b37c641', '83ff93f096bf3fe4a194b17e568d8e4899d5dd3750d15c514c18c8f45d34c4e7', '2025-01-16 13:09:50.757', '20250116123318_fix_likes_field', NULL, NULL, '2025-01-16 13:09:50.145', 1);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
